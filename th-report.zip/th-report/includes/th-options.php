<?php
/**
 * Options for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_Options')) :

    /**
     * TH_Options class.
     */
    final class TH_Options
    {
        /**
         * @var pages
         */
        protected $group = "th_report";

        /**
         * @var pages
         */
        protected $slug = "th_report";

        /**
         * @var pages
         */
        protected $sections = [];

        /**
         * Construct Options.
    	 *
    	 * @param string
         */
        function __construct( $slug = null) {
            if($slug) $this->group = $slug;
            if($slug) $this->slug = $slug;
            add_action( 'admin_init', [ $this, 'init' ] );
            add_action( 'admin_notices', [ $this, 'notice' ] );
            add_action( 'th_report_settings_page_before', [ $this, 'display' ] );
        }

        /**
         * Display form for options page.
         */
        function display() {
 
            echo '<div class="wrap"><form method="post" action="options.php">';
     
                settings_fields( $this->group );
                do_settings_sections( $this->slug );
                submit_button(); 
     
            echo '</form></div>';
     
        }

        /**
         * Add section for options page.
    	 *
    	 * @param string
    	 * @param string
    	 *
    	 * @return string
         */
        function add_section($id,$title){
            $this->sections[$id] = [];
            $this->sections[$id]['title'] = $title;
            $this->sections[$id]['settings'] = [];
            return $id;
        } 
     

        /**
         * Add setting for options page.
    	 *
    	 * @param string
    	 * @param string
    	 * @param string
    	 * @param string
    	 * @param bool
         */
        function add_setting($option, $title, $section, $type = "text", $required = false){
            $this->sections[$section]['settings'][$option] = ['id' => $option,'title' => $title,'type' => $type ,'required' => $required];
        } 
        
        /**
         * Pages add to actions.
         */
        function init() {
            do_action_ref_array( 'th_report_settings_init', [ &$this ] );
            foreach($this->sections as $id => $section){
                add_settings_section( $id, $section['title'], '', $this->slug );
                foreach($section['settings'] as $option_id => $option){
                    register_setting( $this->group, $option_id );
                    add_settings_field($option_id, $option['title'], [ $this, 'field' ], $this->slug, $id , $option);
                }
            }
        }

        /**
         * Display input field to admin ui.
    	 *
    	 * @param array
         */
        function field( $args ){
            $value = get_option( $args[ 'id' ] );
            $attr = "";
            if($args['required']) $attr = "required";

            printf(
                '<input type="%s" id="%s" name="%s" value="%s" %s/>',
                esc_attr( $args[ 'type' ] ),
                esc_attr( $args[ 'id' ] ),
                esc_attr( $args[ 'id' ] ),
                esc_attr( $value ),
                esc_attr( $attr )
            );
        }


        /**
         * Add notice to admin ui.
         */
        function notice() {
            if(
                isset( $_GET[ 'page' ] )
                && $this->slug == $_GET[ 'page' ]
                && isset( $_GET[ 'settings-updated' ] )
                && true == $_GET[ 'settings-updated' ]
            ) {
                echo '<div class="notice notice-success is-dismissible"><p>Save!</p></div>';
            }
        }
    }

endif;
