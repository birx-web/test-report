<?php
/**
 * Admin pages for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_Pages')) :

    /**
     * TH_Pages class.
     */
    final class TH_Pages
    {
        /**
         * @var pages
         */
        protected $title = "TH Report";

        /**
         * @var pages
         */
        protected $slug = "th_report";

        /**
         * @var pages
         */
        protected $icon = "dashicons-welcome-widgets-menus";

        /**
         * @var pages
         */
        protected $pages = [];

        /**
         * Construct pages.
         */
        function __construct($title = null, $slug = null, $icon = null) {
            if($title) $this->title = $title;
            if($slug) $this->slug = $slug;
            if($icon) $this->icon = $icon;
        }

        /**
         * Pages add to actions.
         */
        function init() {
            do_action_ref_array( 'th_report_pages_init', [ &$this ] );
            $slug = $this->slug;
            if(!empty($this->pages[0]['slug'])) $this->slug = $this->slug."_".$this->pages[0]['slug'];
            add_menu_page( $this->title, $this->title, 'manage_options', $this->slug, [$this,'callback'], $this->icon );
            foreach($this->pages as $page){
                add_submenu_page( $this->slug, $page['title'], $page['title'], 'manage_options', $slug.'_'.$page['slug'], [$this,'callback'] );
            }
        }

        /**
         * Add submenu page to admin ui.
         */
        function add_page($title, $slug) {
            $this->pages[] = ['title'=>$title,'slug'=>$slug];
        }

        /**
         * Page generate callback.
         */
        function callback() {
            global $plugin_page;

            echo '<div class="wrap"><h2>' . get_admin_page_title() . '</h2></div><br>';

            $template = apply_filters( 'get_th_report_template', TH_PLUGIN_DIR.'templates/'.$plugin_page.'.php', $plugin_page );

            do_action( $plugin_page.'_page_before' );
            if(file_exists($template)) include($template); 
            do_action( $plugin_page.'_page_after' );

        }

    }

endif;
