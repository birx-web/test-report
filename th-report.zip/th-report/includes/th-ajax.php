<?php
/**
 * Ajax action callbacks for TH Report plugin.
 *
 * @since       1.0.0
 */

if (!defined('ABSPATH')) exit;

if (!class_exists('TH_Ajax')) :

    /**
     * TH_Ajax class.
     */
    final class TH_Ajax
    {

        /**
         * Construct Ajax.
         */
        function __construct() {
            add_action('wp_ajax_generate_report', [$this,'generate_report']);
        }

        /**
         * Ajax callback generate_wp.
         */
        function generate_report() {
            $param = ["address"=>"","note"=>"N/A"];
            if(!empty($_POST["th_report_address"])) $param["address"] = sanitize_text_field($_POST["th_report_address"]);
            if(!empty($_POST["th_report_note"])) $param["note"] = sanitize_text_field($_POST["th_report_note"]);
            if(!empty($_POST["th_report_period"])) $param["period"] = sanitize_text_field($_POST["th_report_period"]);
          
            if($param["period"]=="current"){
                $this->current_report($param);
            }elseif((int)$param["period"]>0){
                $this->on_date_report($param);
            }
            $this->error(__( 'Error request execution', 'th-report' ));
        }

        /**
         * Ajax callback generate current report.
         */
        private function current_report($param) {
            $report = new TH_Report();

            $cw_email = get_option( 'th_cloudways_email' );
            $cw_key = get_option( 'th_cloudways_key' );
            $cw_server = get_option( 'th_cloudways_site_id' );
            $cw_app = get_option( 'th_cloudways_app_id' );

            $report->set_type('current');
            $report->set_site(parse_url(get_option( 'siteurl' ))['host']);
            $report->set_period(date('d F Y'));
            $report->set_addressee($param["address"]);
            $report->set_notes($param["note"]);

            $cw = new TH_CW($cw_email,$cw_key);

            $settings = $cw->get_settings($cw_server);
            if($cw->errors) $this->error($cw->errors);
            if(empty($settings->package_versions)) $this->error(__( "Error getting server package versions", 'th-report' ));
            $settings->package_versions->app = get_bloginfo('version');
            $report->set_details($settings->package_versions);

            $services = $cw->get_services($cw_server);
            if($cw->errors) $this->error($cw->errors);
            $services->ssl = (is_ssl()?"running":"stoped");
            $report->set_core($services);

            $server = $cw->get_server($cw_server);
            if($cw->errors) $this->error($cw->errors);
            $security = [];
            $security['protection'] = 'Active';
            if(!empty($server->backup_frequency)) 
                $security['frequency'] = $server->backup_frequency==1?"Daily":$server->backup_frequency." Days";
            if(!empty($server->backup_retention)) 
                $security['retention'] = $server->backup_retention==1?"Daily":$server->backup_retention." Days";
            $report->set_security($security);

            $report->set_plugins();
 
            if($report->errors) $this->error($report->errors);
                 
            wp_send_json( $report->get_json() );
            die();
        }

        /**
         * The Ajax callback will generate a report by date.
         */
        private function on_date_report($param) {
            $report = get_th_report($param["period"]);
            $report->set_addressee($param["address"]);
            $report->set_notes($param["note"]);
            $report->set_previous_report();

            if($report->errors) $this->error($report->errors);
                 
            wp_send_json( $report->get_json() );
            die();
        }

        /**
         * Ajax callback error.
         */
        function error($errors) {
            if(is_string($errors)) $errors = [$errors];
            wp_send_json( ['errors'=>$errors] );
            die();
        }
            
    }

endif;
