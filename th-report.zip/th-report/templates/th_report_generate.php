<?php
/**
 * The Template for Generate admin page.
 *
 * @version 1.0.0
 */

if (!defined('ABSPATH')) exit; 
?>
<hr>
<pre>
<?php 
$data = get_plugin_data(TH_PLUGIN_FILE);
var_dump(get_bloginfo('version'),ABSPATH,TH_PLUGIN_FILE,$data);
?>
</pre>
<hr>
<div class="wrap">
    <form id="th-generate-form" >
        <input type="hidden" name="action" value="generate_report">
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row"><?php _e( 'Addressee (required)', 'th-report' ); ?></th>
                    <td><input type="text" id="th_report_address" name="th_report_address" value="" required></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e( 'Notes', 'th-report' ); ?></th>
                    <td><textarea name="th_report_note" rows="10" cols="20" id="th_report_note" class="large-text code"></textarea></td>
                </tr>
                <tr>
                    <th scope="row"><?php _e( 'Period (required)', 'th-report' ); ?></th>
                    <td>
                        <select name="th_report_period" id="th_report_period" class="postform" required>
                            <option value="current" selected="selected"><?php _e( 'Current Status Only', 'th-report' ); ?></option>
                            <?php foreach(get_th_reports_periods() as $id => $period): ?>
                                <option value="<?php echo $id; ?>" ><?php echo $period; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="th_report_submit">
            <button type="button" id="th_report_submit" class="button button-primary" onclick="generate_report();"><?php _e( 'Generate Report JSON', 'th-report' ); ?></button>
        </p>
        <div class="th_report_status"></div>
    </form>
</div>
<div class="wrap" id="th-report-form-output">
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row">
                        <p class="th_report_label">
                        <?php _e( 'Report JSON', 'th-report' ); ?>
                        </p>
                        <p class="th_report_buttons">
                            <button type="button" id="th_report_copy" class="button button-default" onclick="copy_report();"><?php _e( 'Copy to clipboard', 'th-report' ); ?></button>
                            <button type="button" id="th_report_clear" class="button button-default" onclick="jQuery('#th_report_output').val('');"><?php _e( 'Clear', 'th-report' ); ?></button>
                        </p>

                    </th>
                    <td>
                        <textarea name="th_report_output" rows="20" id="th_report_output" class="large-text code" readonly></textarea>
                    </td>
                </tr>
            </tbody>
        </table>
</div>
<script>
function generate_report(){
    if(!jQuery("#th-generate-form")[0].checkValidity()){
        jQuery("#th-generate-form")[0].reportValidity();
        return false;
    }
    jQuery('#th_report_submit')[0].disabled = true;
    jQuery('.th_report_status').text('Generating a report on the server...').removeClass('th_error th_success');
    jQuery('#th_report_output').val('').removeClass('th_error');
    jQuery.ajax({
        type: "POST",
        url: ajaxurl,
        data: jQuery('#th-generate-form').serialize(),
        success: function (response) {
            jQuery('#th_report_submit')[0].disabled = false;
            if(response.errors){
                jQuery('.th_report_status').text('There was an error generating the report!').addClass('th_error');
                jQuery('#th_report_output').addClass('th_error');
                let errors = '';
                for (var key in response.errors) {
                    errors += "- " + response.errors[key] + "\n";
                }
                jQuery("#th_report_output").val(errors);
                return false;
            }
            jQuery('.th_report_status').text('Report successfully generated.').addClass('th_success');
            jQuery("#th_report_output").val(JSON.stringify(response));
        },
	    error: function (jqXHR, exception) {
            jQuery('.th_report_status').text('There was an error generating the report!').addClass('th_error');
            jQuery("#th_report_output").addClass('th_error').val('Error response server');
            jQuery('#th_report_submit')[0].disabled = false;
            return false;
	    }
    });
}
function copy_report(){
    let report = jQuery("#th_report_output").val();
    if (navigator && navigator.clipboard && navigator.clipboard.writeText)
        return navigator.clipboard.writeText(report);
    alert('The Clipboard API is not available.');
}
</script>
<style>
    #th-generate-form input[type=text],
    #th-generate-form textarea,
    #th-generate-form select
    {
        width: 100%;
        max-width: 500px;
    }
    div#th-report-form-output p.th_report_label {
        padding-top: 0;
        margin-top: 0;
    }
    div#th-report-form-output p.th_report_buttons  button {
        font-size: 12px;
        display: block;
        margin-bottom: 5px;
        border: 1px solid #313131;
        color: #000;
    }
    .th_report_status.th_success {
        color: #009300;
    }
    .th_report_status.th_error {
        color: #f00;
    }
    #th_report_output {
        background-color: #f7f7f7;
    }
    #th_report_output.th_error {
        color: #f00;
    }
</style>
